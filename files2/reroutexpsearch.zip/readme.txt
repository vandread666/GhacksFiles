------------------------------------------------
RerouteXPSearch (Version 1.0) for Windows XP
� 2006 Ramesh Srinivasan. All rights reserved.
Websites:
	http://windowsxp.mvps.org
	http://www.winhelponline.com
------------------------------------------------


Disclaimer
----------

The software is provided "AS IS" without any warranty, either 
expressed or implied. The author will not be liable for any special,
incidental, consequential or indirect damages due to loss of data or
any other reason.


RerouteXPSearch - Description
------------------------

RerouteXPSearch utility helps you change the destination path for the 
windows XP Start menu Search link. You can point the Search link to 
a third-party Search tool (such as Agent Ransack) so that your 
favorite search application opens when you click the Search button 
in the Windows XP style Start Menu.

Prerequisites
-------------

 - Windows XP / Requires adminstrative privileges to run.
 - This utility is not intended for Windows Classic Start menu.


Version History:
----------------
v1.0 - Dec 04, 2006
