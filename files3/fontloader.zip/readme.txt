Font Loader 2.1
Copyright (c) 2014, www.TrishTech.com. All rights reserved.

Font Loader is Freeware.


Introduction
------------
Font Loader is a tiny portable tool to load fonts temporarily in Windows. It can load and unload true type fonts and open type fonts in Windows for use with any application. After you have done using the fonts, you can unload them easily using Font Loader tool. It works in Windows XP, Vista, 7 and 8.


Requirements
------------
Windows XP/Vista/7/8/8.1


Install/Uninstall
------------------
Installation is not needed. It is a portable application.
Similarly, uninstalling is not required.


DISCLAIMER
----------
Font Loader comes with ABSOLUTELY NO WARRANTY of any kind, whether express or implied. This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 

TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, IN NO EVENT SHALL www.TrishTech.com OR ITS STAFF BE LIABLE FOR ANY SPECIAL, INCIDENTAL, INDIRECT, OR CONSEQUENTIAL DAMAGES WHATSOEVER (INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS INFORMATION, OR ANY OTHER PECUNIARY LOSS) ARISING OUT OF THE USE OF OR INABILITY TO USE THE SOFTWARE PRODUCT, EVEN IF www.TrishTech.com HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.