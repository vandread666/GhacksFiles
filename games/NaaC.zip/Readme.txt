-=- NaaC Readme -=-

NaaC is 100% freeware. You can distribute it as you like, but always free.
NaaC contains gore, violence and blood. So parents beware: you should not play this.

-----------------
Table of contents:

-1- What is NaaC?
-2- Input
-3- Credits
-4- Thanks
------------------


-=1=- WHAT IS NAAC? -=-

NaaC is a fast single-screen shooter in which you can kill thousand of smelling aliens. Play as a space marine, kidnappened from the Earth, packed with only a jetpack and a pistol, and defeat a horde of monster!

Check http://www.bloodymonkey.com/naac/main2db.asp for the latest high scores!

Made with Multimedia Fusion (www.clickteam.com)



-=2=- INPUT -=-

Move  : WASD or Directional Arrows
Aim   : Mouse Pointer
Shoot : Mouse Left Click
Change Weapon : Mouse Right Click

Check in-game HELP for all other keys.



-=3=- CREDITS -=-

->Bloody Monkey Team:

Riccardo -=- Graphics, Code, Music&Samples
Paolo -=- Code, Design
Majco -=- Main Tester, Violence

-> http://www.bloodymonkey.com <-


-=4=- THANKS -=-

->Testers:
Moku, Mr.A, Beppo, Snakesoft, Z4g0, Lupo, pascalman, Cavrimax, max91, cinfa, Killerhurz, TeknoDragooN, PaladinGandalf, lucatarik, Chuck Schuldiner, Ronin, Uzi Rider, Vazkor

->Special Thanks: 
Tato, Hayato, Mei Mato, Gendo Ikari, Elektro

http://www.jrsoftware.org/ -> Inno Setup, a free installer for Windows programs.

http://www.clickteam.com/  -> Multimedia Fusion, a wonderful game tool


And now...

-=- CHEATS! -=-

In Arena Mode:
Shift + R : jump to Boss

Both Arena and Survive Mode:
1 + H : 1 health (combo x10)

Main menu:
Shift + S : Unlock Survive Mode


-=-=-=-=-=-=-=-=-

If you have comments, suggestions, problems, send an e-mail to monkeysoft@gmail.com
Check also www.bloodymonkey.com for news & update!

-=-=-=-=-=-=-=-=-
BloodyMonkey, 2006