Autostart Explorer is Copyright � 2002 Mischel Internet Security. All rights reserved.

Installation
------------
No installation is required. Simply unzip the files in the distribution archive to any
directory and run AutostartExplorer.exe

Support
-------
Support is provided through our online forum, available at www.misec.net/forum. If you have
purchased a commercial license, you may also e-mail support@misec.net to obtain technical
support.

Bugs
----
If you think you've encountered a bug in Autostart Explorer, e-mail support@misec.net 
and describe what problem you are experiencing. Be sure to include details about your
hardware setup and the operating system version you are using.