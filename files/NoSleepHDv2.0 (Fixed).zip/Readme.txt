******************************************************************************************
** 					NoSleepHD v2.0                     	        **
**A Simple program to stop your external hard-drive from going to Auto-Sleep mode.    	**
******************************************************************************************
**    NoSleepHD   (c) 2009 Ashutosh Agarwal. All Rights Reserved    	  		**
**    Version     2.0	                                         			**
**    Date	  March 31, 2009                                      			**
******************************************************************************************

New in Version 2.0
*******************

1. Monitor multiple drives at once.
2. Check if the drive is simply disconnected by user at start-up.

   I.  If drive is disconnected, pause the program and retain the settings until the drive is found.
   II. If the drive is re-connected, resume monitoring drive(s) with saved settings.

3. Drive information tool.
4. Separate 'About' page.
5. Better error handling.
6. PayPal 'Donate' button.


How to use the program:
************************

1. Select any drive on your external hard disk OR a folder on your external hard disk drive.
2. Set the timer. (10 Minutes Recommended)
3. Press 'Start NoSleep Mode'.



Optional Features:
*******************

1. Click 'Info' tab to view drive information.
2. Monitor multiple drives by selecting, more drives in 'Configuration' tab. (Up to 5 External Hard Drives)
3. Hard drive monitoring can be stopped if necessary. (Which would allow the drive to go to auto-sleep.
4. Application can be chosen to sit in the System Tray or simply minimized.
5. Auto-run at start-up can also be enabled.


And that is it! No more annoying waiting/connection problem with your external hard disk.


Thank you for using the program.


Additional Info:
*****************

Product Homepage:	http://nosleephd.codeplex.com

Author:			Ashutosh Agarwal

Email:			agarwal@hotmail.co.uk

Author's Website:	http://www.ashutoshagarwal.com


Donate:
********

NoSleepHD is a free open source project that is developed in personal time. 

You can show your appreciation for NoSleepHD and support future development by donating.

Please find the secure PayPal donate link on Product Homepage.