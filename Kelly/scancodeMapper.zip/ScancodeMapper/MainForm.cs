// Copyright (c) 2002, Sells Brothers, Inc.
// All rights reserved. No warranties extended. Use at your own risk.

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using Microsoft.Win32; // RegistryKey

namespace ScancodeMapper {
  /// <summary>
  /// Summary description for Form1.
  /// </summary>
  public class MainForm : System.Windows.Forms.Form {
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.GroupBox groupBox2;
    private System.Windows.Forms.Splitter splitter1;
    private System.Windows.Forms.ColumnHeader columnHeader3;
    private System.Windows.Forms.ColumnHeader columnHeader4;
    private System.Windows.Forms.MainMenu mainMenu1;
    private System.Windows.Forms.MenuItem menuItem1;
    private System.Windows.Forms.MenuItem fileExit;
    private System.Windows.Forms.MenuItem menuItem6;
    private System.Windows.Forms.ListView desiredMappingListView;
    private System.Windows.Forms.ListView currentMappingListView;
    private System.Windows.Forms.ColumnHeader columnHeader1;
    private System.Windows.Forms.ColumnHeader columnHeader2;
    private System.Windows.Forms.MenuItem menuItem2;
    private System.Windows.Forms.MenuItem helpAboutMenuItem;
    private System.Windows.Forms.MenuItem editAddMappingMenuItem;
    private System.Windows.Forms.MenuItem editRemoveMappingMenuItem;
    private System.Windows.Forms.ContextMenu contextMenu1;
    private System.Windows.Forms.MenuItem addMappingMenuItem;
    private System.Windows.Forms.MenuItem removeMappingMenuItem;
    private System.Windows.Forms.MenuItem fileCommitMenuItem;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public MainForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if (components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

		#region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.currentMappingListView = new System.Windows.Forms.ListView();
      this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
      this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
      this.groupBox2 = new System.Windows.Forms.GroupBox();
      this.desiredMappingListView = new System.Windows.Forms.ListView();
      this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
      this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
      this.splitter1 = new System.Windows.Forms.Splitter();
      this.mainMenu1 = new System.Windows.Forms.MainMenu();
      this.menuItem1 = new System.Windows.Forms.MenuItem();
      this.fileCommitMenuItem = new System.Windows.Forms.MenuItem();
      this.fileExit = new System.Windows.Forms.MenuItem();
      this.menuItem2 = new System.Windows.Forms.MenuItem();
      this.editAddMappingMenuItem = new System.Windows.Forms.MenuItem();
      this.editRemoveMappingMenuItem = new System.Windows.Forms.MenuItem();
      this.menuItem6 = new System.Windows.Forms.MenuItem();
      this.helpAboutMenuItem = new System.Windows.Forms.MenuItem();
      this.contextMenu1 = new System.Windows.Forms.ContextMenu();
      this.addMappingMenuItem = new System.Windows.Forms.MenuItem();
      this.removeMappingMenuItem = new System.Windows.Forms.MenuItem();
      this.groupBox1.SuspendLayout();
      this.groupBox2.SuspendLayout();
      this.SuspendLayout();
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.currentMappingListView});
      this.groupBox1.Dock = System.Windows.Forms.DockStyle.Left;
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(216, 174);
      this.groupBox1.TabIndex = 0;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Current Mappings (from the Registry)";
      // 
      // currentMappingListView
      // 
      this.currentMappingListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
                                                                                             this.columnHeader1,
                                                                                             this.columnHeader2});
      this.currentMappingListView.Dock = System.Windows.Forms.DockStyle.Fill;
      this.currentMappingListView.Location = new System.Drawing.Point(3, 16);
      this.currentMappingListView.Name = "currentMappingListView";
      this.currentMappingListView.Size = new System.Drawing.Size(210, 155);
      this.currentMappingListView.TabIndex = 0;
      this.currentMappingListView.View = System.Windows.Forms.View.Details;
      // 
      // columnHeader1
      // 
      this.columnHeader1.Text = "From Key";
      this.columnHeader1.Width = 86;
      // 
      // columnHeader2
      // 
      this.columnHeader2.Text = "To Key";
      this.columnHeader2.Width = 91;
      // 
      // groupBox2
      // 
      this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                            this.desiredMappingListView});
      this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
      this.groupBox2.Location = new System.Drawing.Point(216, 0);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new System.Drawing.Size(240, 174);
      this.groupBox2.TabIndex = 1;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Desired Mappings (right-click to manage)";
      // 
      // desiredMappingListView
      // 
      this.desiredMappingListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
                                                                                             this.columnHeader3,
                                                                                             this.columnHeader4});
      this.desiredMappingListView.ContextMenu = this.contextMenu1;
      this.desiredMappingListView.Dock = System.Windows.Forms.DockStyle.Fill;
      this.desiredMappingListView.FullRowSelect = true;
      this.desiredMappingListView.Location = new System.Drawing.Point(3, 16);
      this.desiredMappingListView.Name = "desiredMappingListView";
      this.desiredMappingListView.Size = new System.Drawing.Size(234, 155);
      this.desiredMappingListView.TabIndex = 1;
      this.desiredMappingListView.View = System.Windows.Forms.View.Details;
      // 
      // columnHeader3
      // 
      this.columnHeader3.Text = "Key";
      this.columnHeader3.Width = 68;
      // 
      // columnHeader4
      // 
      this.columnHeader4.Text = "Mapped To Key";
      this.columnHeader4.Width = 112;
      // 
      // splitter1
      // 
      this.splitter1.Location = new System.Drawing.Point(216, 0);
      this.splitter1.Name = "splitter1";
      this.splitter1.Size = new System.Drawing.Size(3, 174);
      this.splitter1.TabIndex = 2;
      this.splitter1.TabStop = false;
      // 
      // mainMenu1
      // 
      this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.menuItem1,
                                                                              this.menuItem2,
                                                                              this.menuItem6});
      // 
      // menuItem1
      // 
      this.menuItem1.Index = 0;
      this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.fileCommitMenuItem,
                                                                              this.fileExit});
      this.menuItem1.Text = "&File";
      // 
      // fileCommitMenuItem
      // 
      this.fileCommitMenuItem.Index = 0;
      this.fileCommitMenuItem.Text = "&Commit Changes";
      this.fileCommitMenuItem.Click += new System.EventHandler(this.fileCommitMenuItem_Click);
      // 
      // fileExit
      // 
      this.fileExit.Index = 1;
      this.fileExit.Text = "E&xit";
      this.fileExit.Click += new System.EventHandler(this.fileExit_Click);
      // 
      // menuItem2
      // 
      this.menuItem2.Index = 1;
      this.menuItem2.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.editAddMappingMenuItem,
                                                                              this.editRemoveMappingMenuItem});
      this.menuItem2.Text = "&Edit";
      // 
      // editAddMappingMenuItem
      // 
      this.editAddMappingMenuItem.Index = 0;
      this.editAddMappingMenuItem.Text = "&Add Mapping...";
      this.editAddMappingMenuItem.Click += new System.EventHandler(this.editAddMappingMenuItem_Click);
      // 
      // editRemoveMappingMenuItem
      // 
      this.editRemoveMappingMenuItem.Index = 1;
      this.editRemoveMappingMenuItem.Text = "&Remove Selected Mappings";
      this.editRemoveMappingMenuItem.Click += new System.EventHandler(this.editRemoveMappingMenuItem_Click);
      // 
      // menuItem6
      // 
      this.menuItem6.Index = 2;
      this.menuItem6.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.helpAboutMenuItem});
      this.menuItem6.Text = "&Help";
      // 
      // helpAboutMenuItem
      // 
      this.helpAboutMenuItem.Index = 0;
      this.helpAboutMenuItem.Text = "&About...";
      this.helpAboutMenuItem.Click += new System.EventHandler(this.helpAbout_Click);
      // 
      // contextMenu1
      // 
      this.contextMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                 this.addMappingMenuItem,
                                                                                 this.removeMappingMenuItem});
      // 
      // addMappingMenuItem
      // 
      this.addMappingMenuItem.Index = 0;
      this.addMappingMenuItem.Text = "&Add Mapping...";
      this.addMappingMenuItem.Click += new System.EventHandler(this.addMappingMenuItem_Click);
      // 
      // removeMappingMenuItem
      // 
      this.removeMappingMenuItem.Index = 1;
      this.removeMappingMenuItem.Text = "&Remove Selected Mappings...";
      this.removeMappingMenuItem.Click += new System.EventHandler(this.removeMappingMenuItem_Click);
      // 
      // MainForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(456, 174);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.splitter1,
                                                                  this.groupBox2,
                                                                  this.groupBox1});
      this.Menu = this.mainMenu1;
      this.Name = "MainForm";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "Scancode Mapper";
      this.Closing += new System.ComponentModel.CancelEventHandler(this.MainForm_Closing);
      this.Load += new System.EventHandler(this.MainForm_Load);
      this.groupBox1.ResumeLayout(false);
      this.groupBox2.ResumeLayout(false);
      this.ResumeLayout(false);

    }
		#endregion

    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    [STAThread]
    static void Main() {
      Application.Run(new MainForm());
    }

    KeyMappings currentMappings = null;
    KeyMappings desiredMappings = new KeyMappings();

    private void helpAbout_Click(object sender, System.EventArgs e) {
      (new AboutBox()).ShowDialog();
    }

    private void fileCommitMenuItem_Click(object sender, System.EventArgs e) {
      CommitChanges();
      GetCurrentMappings();
      ShowMappings(currentMappingListView, currentMappings);
    }

    private void fileExit_Click(object sender, System.EventArgs e) {
      Close();
    }

    void ShowMappings(ListView listView, KeyMappings mappings) {
      listView.Items.Clear();
      foreach( KeyMapping mapping in mappings ) {
        ListViewItem item = listView.Items.Add(mapping.FromKey.ToString());
        item.SubItems.Add(mapping.ToKey.ToString());
        item.Tag = mapping;
      }
    }

    void GetCurrentMappings() {
      byte[] bytes = null;
      using( RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Keyboard Layout") ) {
        try {
          bytes = (byte[])key.GetValue("Scancode Map");
        }
        catch( ArgumentException ) {
        }
      }

      currentMappings = (bytes != null ? new KeyMappings(bytes) : new KeyMappings());
    }

    private void MainForm_Load(object sender, System.EventArgs e) {
      GetCurrentMappings();

      foreach( KeyMapping mapping in currentMappings ) {
        desiredMappings.Add(mapping.FromKey, mapping.ToKey);
      }

      ShowMappings(currentMappingListView, currentMappings);
      ShowMappings(desiredMappingListView, desiredMappings);
    }

    void AddMapping() {
      MappingForm dlg = new MappingForm();
      if( dlg.ShowDialog() == DialogResult.OK ) {
        if( desiredMappings.AlreadyMaps(dlg.FromKey) ) {
          MessageBox.Show("Can't map two keys from the same key: " + dlg.FromKey.ToString(), "Scancode Mapper");
          return;
        }

        desiredMappings.Add(dlg.FromKey, dlg.ToKey);
        ShowMappings(desiredMappingListView, desiredMappings);
      }
    }

    void RemoveSelectedMapping() {
      foreach( ListViewItem item in desiredMappingListView.SelectedItems ) {
        desiredMappings.Remove((KeyMapping)item.Tag);
      }
      ShowMappings(desiredMappingListView, desiredMappings);
    }

    void CommitChanges() {
      DialogResult res = MessageBox.Show("WARNING! If you messed up your key mappings, e.g. mapped A to None and your password includes an A, then you're going to be in trouble and you shouldn't commit these changes.\r\n\r\nAre you double-secret sure that you want to commit these changes?", "Scancode Mappings", MessageBoxButtons.YesNo);
      if( res == DialogResult.No ) {
        MessageBox.Show("Changes not committed <whew>", "Scancode Mapper");
        return;
      }

      using( RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Keyboard Layout", true) ) {
        key.SetValue("Scancode Map", desiredMappings.ToBytes());
      }

      MessageBox.Show("Changes committed to the Registry. Restart Windows to enjoy their benefits.", "Scancode Mapper");
    }

    private void addMappingMenuItem_Click(object sender, System.EventArgs e) {
      AddMapping();
    }

    private void removeMappingMenuItem_Click(object sender, System.EventArgs e) {
      RemoveSelectedMapping();
    }

    private void editAddMappingMenuItem_Click(object sender, System.EventArgs e) {
      AddMapping();
    }

    private void editRemoveMappingMenuItem_Click(object sender, System.EventArgs e) {
      RemoveSelectedMapping();
    }

    private void MainForm_Closing(object sender, System.ComponentModel.CancelEventArgs e) {
      if( currentMappings == desiredMappings ) return;

      DialogResult res = MessageBox.Show("Commit changes?", "Scancode Mapper", MessageBoxButtons.YesNo);
      if( res == DialogResult.Yes ) {
        CommitChanges();
      }
    }

  }
}












