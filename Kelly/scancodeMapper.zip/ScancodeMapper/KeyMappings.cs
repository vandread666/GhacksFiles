// Copyright (c) 2002, Sells Brothers, Inc.
// All rights reserved. No warranties extended. Use at your own risk.
// Built using http://www.microsoft.com/hwdev/tech/input/w2kscan-map.asp
// TODO: Update to handle weird things like Insert as per: http://www.microsoft.com/hwdev/tech/input/Scancode.asp

using System;
using System.Windows.Forms;
using System.Collections;
using System.Diagnostics;
using System.Runtime.InteropServices; // DllImport

namespace ScancodeMapper {
  public class KeyMappings : IEnumerable {
    public KeyMappings() {
    }

    public KeyMappings(byte[] bytes) {
      if( bytes.Length % 4 != 0 ) throw new ApplicationException("Unknown format");

      // version
      uint version = BitConverter.ToUInt32(bytes, 0);
      if( version != 0 ) throw new ApplicationException("Unknown version: " + version);

      // flags
      uint flags = BitConverter.ToUInt32(bytes, 4);
      if( flags != 0 ) throw new ApplicationException("Unknown flags: " + flags);

      // count
      uint count = BitConverter.ToUInt32(bytes, 8);

      // mappings
      for( int i = 0; i != count - 1; ++i ) {
        uint mapTo = BitConverter.ToUInt16(bytes, i * 4 + 12);
        uint mapFrom = BitConverter.ToUInt16(bytes, i * 4 + 14);
        mappings.Add(new KeyMapping(ToVirtualKey(mapFrom), ToVirtualKey(mapTo)));
      }

      // null termination
      uint term = BitConverter.ToUInt32(bytes, 12+((int)count-1)*4);
      if( term != 0 ) throw new ApplicationException("Unknown termination: " + term);
    }

    static void CopyBytes(byte[] dest, uint offset, byte[] src) {
      for( int i = 0; i != src.Length; ++i ) {
        dest[offset + i] = src[i];
      }
    }

    public byte[] ToBytes() {
      byte[] bytes = new byte[4+4+4+4*mappings.Count+4];
      
      // version
      CopyBytes(bytes, 0, BitConverter.GetBytes((uint)0));

      // flags
      CopyBytes(bytes, 4, BitConverter.GetBytes((uint)0));

      // count
      CopyBytes(bytes, 8, BitConverter.GetBytes((uint)mappings.Count + 1));

      // mappings
      int i = 0;
      foreach( KeyMapping mapping in mappings ) {
        CopyBytes(bytes, (uint)(i * 4 + 12), BitConverter.GetBytes((UInt16)ToScancode(mapping.ToKey)));
        CopyBytes(bytes, (uint)(i * 4 + 14), BitConverter.GetBytes((UInt16)ToScancode(mapping.FromKey)));
        ++i;
      }

      // null termination
      CopyBytes(bytes, (uint)(12+mappings.Count*4), BitConverter.GetBytes((uint)0));

      return bytes;
    }

    public void Add(Keys fromKey, Keys toKey) {
      mappings.Add(new KeyMapping(fromKey, toKey));
    }

    public void Remove(KeyMapping mapping) {
      mappings.Remove(mapping);
    }

    public bool AlreadyMaps(Keys fromKey) {
      foreach( KeyMapping mapping in mappings ) {
        if( ToScancode(mapping.FromKey) == ToScancode(fromKey) ) return true;
      }

      return false;
    }

    public int Count {
      get { return mappings.Count; }
    }

    public override int GetHashCode() {
      return base.GetHashCode();
    }

    public override bool Equals(object rhs) {
      return this == (KeyMappings)rhs;
    }

    public static bool operator!=(KeyMappings lhs, KeyMappings rhs) {
      return !(lhs == rhs);
    }

    public static bool operator==(KeyMappings lhs, KeyMappings rhs) {
      if( Object.ReferenceEquals(lhs, null) || Object.ReferenceEquals(rhs, null) ) return false;
      if( lhs.Count != rhs.Count ) return false;
      foreach( KeyMapping mapping in lhs.mappings ) {
        if( !rhs.mappings.Contains(mapping) ) return false;
      }
      
      return true;
    }

    [DllImport("user32.dll")]
    static extern uint MapVirtualKey(uint wCode, int wMapType);

    static Keys ToVirtualKey(uint scancode) {
      return (Keys)MapVirtualKey(scancode, 3);
    }

    static uint ToScancode(Keys vkey) {
      return MapVirtualKey((uint)vkey, 0);
    }

    ArrayList mappings = new ArrayList();

    #region Implementation of IEnumerable
    public IEnumerator GetEnumerator() {
      return mappings.GetEnumerator();
    }
    #endregion
  }

  public class KeyMapping {
    public KeyMapping(Keys from, Keys to) {
      this.from = from;
      this.to = to;
    }

    Keys from = Keys.None;
    Keys to = Keys.None;

    public Keys FromKey {
      get { return from; }
      set { from = value; }
    }

    public Keys ToKey {
      get { return to; }
      set { to = value; }
    }

    public override int GetHashCode() {
      return base.GetHashCode();
    }

    public override bool Equals(object rhs) {
      return this == (KeyMapping)rhs;
    }

    public static bool operator!=(KeyMapping lhs, KeyMapping rhs) {
      return !(lhs == rhs);
    }

    public static bool operator==(KeyMapping lhs, KeyMapping rhs) {
      if( lhs.FromKey != rhs.FromKey ) return false;
      if( lhs.ToKey != rhs.ToKey ) return false;
      return true;
    }

  }

}












