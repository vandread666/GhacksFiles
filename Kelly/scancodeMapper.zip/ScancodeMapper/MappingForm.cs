// Copyright (c) 2002, Sells Brothers, Inc.
// All rights reserved. No warranties extended. Use at your own risk.

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Reflection;

namespace ScancodeMapper {
  /// <summary>
  /// Summary description for MappingForm.
  /// </summary>
  public class MappingForm : System.Windows.Forms.Form {
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Button okButton;
    private System.Windows.Forms.Button cancelButton;
    private System.Windows.Forms.ComboBox fromKeyComboBox;
    private System.Windows.Forms.ComboBox toKeyComboBox;
    private System.Windows.Forms.ErrorProvider errorProvider1;
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.Container components = null;

    public MappingForm() {
      //
      // Required for Windows Form Designer support
      //
      InitializeComponent();

      //
      // TODO: Add any constructor code after InitializeComponent call
      //
    }

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose( bool disposing ) {
      if( disposing ) {
        if(components != null) {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

    #region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.label1 = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.okButton = new System.Windows.Forms.Button();
      this.cancelButton = new System.Windows.Forms.Button();
      this.fromKeyComboBox = new System.Windows.Forms.ComboBox();
      this.toKeyComboBox = new System.Windows.Forms.ComboBox();
      this.errorProvider1 = new System.Windows.Forms.ErrorProvider();
      this.SuspendLayout();
      // 
      // label1
      // 
      this.label1.Location = new System.Drawing.Point(16, 16);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(64, 23);
      this.label1.TabIndex = 0;
      this.label1.Text = "From Key";
      this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // label2
      // 
      this.label2.Location = new System.Drawing.Point(16, 48);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(64, 23);
      this.label2.TabIndex = 2;
      this.label2.Text = "To Key";
      this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // okButton
      // 
      this.okButton.DialogResult = System.Windows.Forms.DialogResult.OK;
      this.okButton.Location = new System.Drawing.Point(48, 88);
      this.okButton.Name = "okButton";
      this.okButton.TabIndex = 4;
      this.okButton.Text = "OK";
      this.okButton.Click += new System.EventHandler(this.okButton_Click);
      // 
      // cancelButton
      // 
      this.cancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
      this.cancelButton.Location = new System.Drawing.Point(136, 88);
      this.cancelButton.Name = "cancelButton";
      this.cancelButton.TabIndex = 5;
      this.cancelButton.Text = "Cancel";
      // 
      // fromKeyComboBox
      // 
      this.fromKeyComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.fromKeyComboBox.Location = new System.Drawing.Point(88, 16);
      this.fromKeyComboBox.Name = "fromKeyComboBox";
      this.fromKeyComboBox.Size = new System.Drawing.Size(121, 21);
      this.fromKeyComboBox.Sorted = true;
      this.fromKeyComboBox.TabIndex = 1;
      // 
      // toKeyComboBox
      // 
      this.toKeyComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.toKeyComboBox.Location = new System.Drawing.Point(88, 48);
      this.toKeyComboBox.Name = "toKeyComboBox";
      this.toKeyComboBox.Size = new System.Drawing.Size(121, 21);
      this.toKeyComboBox.Sorted = true;
      this.toKeyComboBox.TabIndex = 3;
      // 
      // errorProvider1
      // 
      this.errorProvider1.DataMember = null;
      // 
      // MappingForm
      // 
      this.AcceptButton = this.okButton;
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.CancelButton = this.cancelButton;
      this.ClientSize = new System.Drawing.Size(234, 126);
      this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                  this.fromKeyComboBox,
                                                                  this.okButton,
                                                                  this.label1,
                                                                  this.label2,
                                                                  this.cancelButton,
                                                                  this.toKeyComboBox});
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = "MappingForm";
      this.Text = "Scancode Mapping";
      this.Load += new System.EventHandler(this.MappingForm_Load);
      this.ResumeLayout(false);

    }
    #endregion

    private void MappingForm_Load(object sender, System.EventArgs e) {
      foreach( string key in Enum.GetNames(typeof(Keys)) ) {
        fromKeyComboBox.Items.Add(key);
        toKeyComboBox.Items.Add(key);
      }
      fromKeyComboBox.SelectedItem = "None";
      toKeyComboBox.SelectedItem = "None";
    }

    private void okButton_Click(object sender, System.EventArgs e) {
      Control controlToActivate = null;
      string err = null;
      string fromKey = fromKeyComboBox.SelectedItem.ToString();
      string toKey = toKeyComboBox.SelectedItem.ToString();

      if( err == null && fromKey == "None" ) {
        controlToActivate = fromKeyComboBox;
        err = "Can't map from 'None'";
      }

      if( err == null && fromKey == toKey ) {
        controlToActivate = toKeyComboBox;
        err = "Can't map to same key";
      }

      if( err != null ) {
        this.DialogResult = DialogResult.None;
        this.ActiveControl = controlToActivate;
        errorProvider1.SetError(controlToActivate, err);
        return;
      }

      foreach( Control control in this.Controls ) {
        errorProvider1.SetError(control, null);
      }

    }

    public Keys FromKey {
      get {
        return (Keys)Enum.Parse(typeof(Keys), fromKeyComboBox.SelectedItem.ToString());
      }
      set {
        fromKeyComboBox.SelectedItem = value.ToString();
      }
    }

    public Keys ToKey {
      get {
        return (Keys)Enum.Parse(typeof(Keys), toKeyComboBox.SelectedItem.ToString());
      }
      set {
        toKeyComboBox.SelectedItem = value.ToString();
      }
    }

  }
}
