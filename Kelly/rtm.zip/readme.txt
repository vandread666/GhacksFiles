
Remote Task Manager: readme
~~~~~~~~~~~~~~~~~~~~~~~~~~~

Please read this file carefully (especially the "Installation" chapter)
before installing the program to your computer.

IMPORTANT! If you obtained RTM not from our web page, but from another
source (CD or a software library), please visit our home page where you
might find a later version.


Contents
~~~~~~~~

 Program information
 Company information
 Description
 Installation (!)
 Registration
 Copyright and license
 Technical support


Program information
~~~~~~~~~~~~~~~~~~~

Program Archive Name:
 rtm.zip
Program Name:
 Remote Task Manager
Program Version:
 3.7.51
Program Release Date:
 November 25, 2002
Target OS:
 Windows NT 4.0, Windows 2000, Windows XP
Platform:
 Intel x86
Brief Description:
 The remote manager for tasks, processes, services, devices, shares and events
Software type:
 30-day trial


Company information
~~~~~~~~~~~~~~~~~~~

Company Name:
  SmartLine, Inc.
Author Name:
  Ashot Oganesyan K
Contact E-mail Address:
  support@protect-me.com
  sales@protect-me.com
Contact WWW URL:
  http://www.ntutility.com


Description
~~~~~~~~~~~

Remote Task Manager (RTM) is a systems control interface that can be run
from any remote Windows NT/2000/XP computer. This lets Systems Administrators
control most aspects of a remote environment. The simple-to-use, tabbed
interface separates applications, services, devices, processes, events,
shared resources and performance monitor, making each of these very easy
to manage.

With RTM you can:

 - Monitor all running tasks, processes, services, devices, shared resources
   and events on remote computers

 - Watch features of running tasks (the handle of the main window,
   process ID, etc.)

 - Watch features of running processes (process ID, CPU time, privileges
   used, memory, priority, etc.)

 - See which process is associated with a selected task

 - See which process is associated with a selected service

 - End a selected task correctly

 - Terminate a selected process at any time

 - Change priority of a selected process

 - Control which CPUs the process will be allowed to execute on

 - Stop, start, restart, pause and continue any selected service or device

 - Change startup parameters of a service or a device (name, account, startup
   type, dependencies, etc.)

 - Change service's repair parameters on Windows 2000/XP

 - Watch dependent services or devices

 - Adjust service's and device's security (permissions, auditing and owner)

 - Clear event logs

 - Archive event logs

 - Monitor a dynamic overview of the computer's performance (CPU and memory
   usage)

 - Manage shared resources on remote computers

 - Monitor all open TCP and UDP ports

 - Shut down and reboot remote computers

 - Create processes on remote computers

 - Lock computers remotely

 - And much more


Installation
~~~~~~~~~~~~

To install RTM you MUST have administrative privileges.

Run "setup.exe". You'll need to select the target directory for the install.

If you wish to install RTM without an user intervention you should run
RTM Setup with the /s parameter (e.g. "c:\setup.exe /s"). This gives an
install that can be used from within a batch file. There is a special
configuration file for silent setup: rtm.ini. With this file, you can
customize the RTM installation parameters. For example:

 1. "Install" parameters:

      Service    - RTM Service and its related files will be installed
      Manager    - RTM Manager and its related files will be installed
      Documents  - documentation (readme.txt, register.txt) will be installed

    To specify a destination directory for RTM, you can supply
    the parameter InstallDir

    If you have the registration key-file for RTM, you can specify a directory
    with this file in the parameter RegFileDir

 2. "Misc" parameters:

      Run - this parameter is used to launch an application or execute a batch
            file after a successful install.


Registration
~~~~~~~~~~~~

See "register.txt" file.


Copyright and license
~~~~~~~~~~~~~~~~~~~~~

See "license.txt" file.


Technical support
~~~~~~~~~~~~~~~~~

See "contacts.txt" file.



                                         Copyright(c) 1998-2002 SmartLine Inc.
                                                          All rights reserved.
                            Remote Task Manager is trademark of SmartLine Inc. 