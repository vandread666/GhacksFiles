________________________________________________________________ 

FavesToGo, Version 1.0
Copyright (c) 2001 Ziff Davis Media, Inc.
Written by Charles Petzold
First Published in PC Magazine, US Edition, April 17, 2001, v20n08
http://www.pcmag.com/utilities/
________________________________________________________________ 

PLATFORMS:
Windows 95, Windows 98, Windows ME, Windows NT 4, Windows 2000

DESCRIPTION:
You can access the Web from just about any computer, but that's little help if you can't remember where you want to go. FavesToGo converts your collection of Internet Explorer favorites into a single HTML file that can be easily copied to a floppy disk or emailed to yourself for access while traveling.

Netscape Navigator stores your bookmarks in a single HTML file, but Internet Explorer stores its Favorites in a hard-to-transport directory structure with each link in a separate file. Internet Explorer 5 and later offers an Export feature that creates a bookmark.htm file, but this file lacks navigation features and is not organized conveniently.

FavesToGo puts shortcuts that are not in folders at the top of the list, rather than the bottom. You can customize the colors in FavesToGo so it's easily distinguished from the Web pages you link to from it, and navigation links let you jump between folders. Make FavesToGo.html your home page for an easier way to access your Favorites. When your Favorites menu changes, simple run the program again and it will rebuild the HTML file.

REVISION HISTORY:
Initial release.

THANKS TO OUR BETA TESTERS:
Bob Abrahams
Dennis Cummins
Robert Eisenbach
David Morse
John Sulmeyer
 
INSTALLATION:
To install FavesToGo, unzip the program files in a subdirectory on your hard disk, and create a shortcut to FavesToGo.exe. To uninstall FavesToGo, simply delete its program files. For details on program operation, refer to the program's online help file.

FILE LIST:
FavesToGo.exe - the FavesToGo program
readme.txt    - the file you are reading
license.txt   - PC Magazine Utilities license agreement
faves_src.zip - FavesToGo source code (for programmers)

SUPPORT:
Help for PC Magazine's free utilities can be obtained in our online discussion area on the World Wide Web (www.pcmag.com/utilities/support.html). You may find an answer to your question simply by reading the posted messages. The authors of current utilities generally visit this forum daily. If the author is not available and the forum sysops can't answer your question, the Utilities column editor, who also checks the forum each day, will contact the author for you.

LICENSE INFORMATION:
PC Magazine programs are copyrighted and cannot be distributed, whether modified or unmodified. Use is subject to the terms and conditions of the license agreement distributed with the programs.

----

Charles Petzold, the author of FavesToGo, is a Contributing Editor to PC Magazine and the author of Programming Windows. You can visit his Web site at www.charlespetzold.com. Sheryl Canter is the editor of the Utilities column, and a Contributing Editor to PC Magazine.

