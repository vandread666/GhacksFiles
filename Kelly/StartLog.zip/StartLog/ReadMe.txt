 
 StartUp Log v01.58 - for Windows 95/98


 This little program will show you all the programs that run
 automatically when Windows is started.
 Using this log can be a quick way to spot trojans. 
 
 Please see the Rx-Pack download for further assistance.

 StartUp Log will not make any changes to your Registry.
 It will not leave any unknown files on your computer.
 
 Just click on it and let it do the rest.


                    ~ Freeware by rmbox - 12/2/2001


 Additional notes:

 StartUp Log was made to be especially helpful to remote PC Techs.
 It allows a user to post or e-mail detailed start-up specifics.
 This can be useful when looking for start-up problems of any kind.
 
 The StartUp Log has had many updates since it's v1.00 beginning.
 The updates have been necessary due to constant trojan evolution.
 The addition of the "Miscellaneous StartUp Configurations" to the
 logging has kept StartUp Log on the "cutting edge" of this field.

 The "Supplemental Environment Information" section was added to
 show possible important non-standard environment variations.
 A non-standard winbootdir or windir can cause false logging.

 A number of the more unusual start-ups will log only if 
 they actually exist on the particular system.
 This generates a smaller more relevant StartUp.Log

 Many advanced trojans replace or are "joined" to legitimate programs.
 This can make identifying them extremely difficult.
 If the trojan is started with Windows, the chances are very good
 that it's start-up or start-up program will be listed.
 
 Remember, the most important defense one can have against trojans
 or viruses of any kind, is a good "updated" Anti Virus program.
 

                                                 ~ rmbox


 * Copy and Paste help for new PC users:

 Go to the top of the StartUp.Log window, click "Edit", click
 "Select All", then click "Edit" again and click "Copy". 
 Then right click on where you desire to paste the copied
 information and click "Paste". 

 Or, "drag" (hold your left mouse button down) over a section of
 text to highlight it. 
 Put your mouse arrow on the selected highlighted text, and click
 your right mouse button. 
 Put your mouse arrow on "Copy" from the menu and click your left
 mouse button. 
 Then right click on where you desire to paste the copied information
 and left click on "Paste" from the menu. 

(The StubPath.txt file information will usually not need to be copied and pasted)

                                   ---- (end) ----

