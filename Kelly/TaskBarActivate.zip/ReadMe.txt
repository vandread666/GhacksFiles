TaskBar Activate v2.4
09/1999

Pierre-Marie DEVIGNE
pmdevigne@nordnet.fr
http://home.nordnet.fr/~pmdevigne/


Install :
=========

Launch the Setup file. It creates an application folder for the Taskbar
Activate files. It also creates icons in the program menu and puts
an icon in the startup folder.
Remark: No files are copied in the Windows or System directories.


Usage :
=======

TaskBar Activate is an application which manage the Windows taskbar
for activation and deactivation better then Windows does.

When the mouse is in the taskbar edge of the screen, it activate the
taskbar if the taskbar doesn't activate itself (usually if you use
full-screen windows and want to switch to another task).
It also allow a smoother activation of the taskbar :
 - activation after a timer
 - activation even with an "always on top" window.

Since version 2.3, this action has been extended to other Windows bars.
To be managed by Taskbar Activate, a bar must be attached to a screen
edge and must have an autohide feature. If it is not an autohide one,
Windows don't list it so Taskbar Activate cannot manage it (the taskbar
is managed in all cases, autohide or not-autohide).
Bars are managed differently than the taskbar : there is no highlighted
line over them.
If you don't use bars, you can uncheck this feature in the settings
windows to use less processor time.
New : bars are hidden when Taskbar Activate is starting.

To see the statistics of taskbar activations made by Taskbar Activate,
open the About dialog box. :-)


Known problems :
================

It seems that there is some problems with the Office bar on some
machines. If you want use the Office bar and Taskbar Activate, please
uncheck "Manage other Windows bars" in the setting window. Other bars
(like I.E.4 bars) are correctly working with Taskbar Activate.
If you are using an utility which resize or move windows, it can make
Taskbar Activate not working correctly. If you have this problem, please
disable this feature in your utility.


Configure Taskbar Activate :
============================

Right click on the application icon in the taskbar area and choose the 
Settings menu.
You can also right click on the taskbar edge of the screen (when Taskbar
Activate is hilighted), the same menu is shown.

Many settings can be configured. See the help file for more details.

Available configurations : 
 - delayed activation of the taskbar.
 - access to the taskbar with always on top windows.
 - show or hide the icon of Taskbar Activate in the taskbar.
 - hilight Taskbar Activate when mouse comes over it.
 - disable management of one bar.
 - completly hide bars when they are no active.
I have added an advanced setting page to solve problems with specific bars. 


Exit TaskBar Activate :
=======================

Click on the icon in the taskbar with the right mouse button and choose
the Exit option in the popup menu.


Uninstall Taskbar Activate :
===========================

Use Add/Remove programs in the control panel and select Taskbar Activate
to completly remove the application.
If you want to remove settings, they are saved in the registry here :
HKCU\Software\PMDevigneSoft\ActiveTache.


Remarks :
=========

This application is "e-mailware". That is if you like this program or you
want to comment it or to tell me how to enhance it, please send me an
e-mail (see the About dialog box).

This application is provided "AS IS" without warranty of any kind.


Evolutions :
============

v2.4 (09/1999)
        The taskbar can be completly hidden in the background (like it was
        already for other bars).
        The color fo hilighted line can be modified.
        Bars are hidden when Taskbar Activate starts (it is no long necessary
        to activate them once).
        Bars management improved.
        Bars hidden become visible when Taskbar Activate is in suspend mode.
        An advanced setting page has been added to solve problem with
        specific bars.
        Statistics timer is saved :-).
        Bars get back in the background even if they have been activated.
        And of course, some other minor improvements.
v2.3 (01/1999)
        Taskbar Activate now manages all Windows bars (the bar must have an
        autohide feature).
        I have changed the settings window to had the bars management feature.
        Taskbar Activate looks if the active bar has not a dependant window
        that is active before get back this bar in the background. The
        dependant window was in fact get back also.
        Taskbar Activate can be suspended. Click once on the icon application
        in the taskbar (left click). Click once more to reactivate T.A.
        I have made the setup by myself. So, size of the setup file has been
        divided by 2!
        Always some little changes.
v2.2 (10/1998)
        Added an install/desinstall mechanism.
        Added a help file in HTML format.
        Taskbar Activate is quite as complete as a commercial software! :-)
v2.1 (09/1998)
        Bug correction : with certains versions of Window 95, Taskbar Activate
        did not appear at the right place if the taskbar was not in the bottom
        of the screen.
        Some little changes.
v2.0 (08/1998)
        Major release
        Bug correction in statistics which may crash Taskbar Activate.
        Bug correction in the displayed icon in the taskbar for a best remove
        when the application ends.
        Added a configuration window.
        Added a context menu when right clic on the taskbar icon or on the
        hilighted line on the screen edge.
        Option for delayed activation of the taskbar.
        Option to keep access to the taskbar over always on top windows.
        Icon in the taskbar can be hidden.
v1.2 (07/1998)
        The number of taskbar activation made by Taskbar Activate is
        now shown in the About dialog box. You can now realize how Taskbar
        Activate is usefull for you :-) !
        The icon in the taskbar area is now removed after 2 minutes. You can
        recover it if you launch Taskar Activate a second time.
        Correction of a display bug concerning the email address and http
        address if you use non-standart system colors.
v1.1 (06/1998)
        Now compatible with the multi-display support in Windows 98!
        You can place the TaskBar where you want on any monitor.
v1.0.1 (05/1998)
        Correction of a small bug with About box buttons
v1.0 (05/1998)
        - 1st public release
        Activate the taskbar when the mouse moves on it.
        Manage the moving of the taskbar and screen resize.
        Works on Windows95 and on Windows 98 (with some hair out).
