________________________________________________________________ 

AutoWhat?, Version 2.1
Copyright (c) 2002 Ziff Davis Media, Inc.
Written by Neil J. Rubenking
First Published in PC Magazine, US Edition, March 26, 2002, v21n06
http://www.pcmag.com/utilities/
________________________________________________________________ 

PLATFORMS:
Windows 95/98/Me/NT4/2000/XP

DESCRIPTION:
Internet Explorer 5 and later has an AutoComplete feature to speed the process of filling in Web-based forms. If this feature is turned on, each time you submit data in a form, the information is encrypted and stored on your local machine. The next time you encounter a form that has a field with the same internal field name, IE will help you complete that field. As soon as you type a letter that matches the beginning of any recorded value for that field, IE will display a list of possible values from which you can choose. To see all saved values, press the down arrow.
�
The Internet Options applet in Control Panel lets you turn AutoComplete on and off, and clear all recorded data. It doesn't, however, let you clear form fields selectively or view the stored data. This issue's utility, AutoWhat? 2, fills the gap. With AutoWhat? 2 you can view the values stored for each input field name, delete incorrect ones, and pre-load the system with additional values. AutoWhat? was originally released as a PC Magazine Extra utility in November 1999. 

REVISION HISTORY:
Changes in Version 2.1:
- On some NT-based systems, all fields were coming up blank. This was because the Security ID (which identifies the current user) was sometimes not obtained correctly or not correctly translated into text. This has been fixed.
- On some Windows 9x systems, all fields were coming up blank. This was due to a bug in the automatic logon procedure (see Microsoft Knowledge Base article Q141858), that prevented AutoWhat from obtaining the correct user name. Now when the username is blank or lacks AutoComplete data, AutoWhat? asks the user to choose from a list of usernames that do have AutoComplete data, and remembers the choice for next time.
- On some NT-based systems, a timing issue caused the list of AutoComplete fields to come up short. This has been fixed.
- The Help file now has a Troubleshooting page.

Changes in Version 2.0:
- Improved interface.
- Support for NT-based operating systems.

THANKS TO OUR BETA TESTERS:
Alec Burgess
Herbert Bushong
Josh Fitzgerald
Ken Holt
Bruno Sonnino
John Sulmeyer
Greg Wolking
 
INSTALLATION:
To install AutoWhat?, unzip the downloaded file into a temporary folder and run the supplied installation program SETUP.EXE. This will copy the program files to your hard disk and create a shortcut to AutoWhat? in your Start menu. To uninstall the program, use the Add/Remove Programs applet in the Windows Control Panel. For details on program operation, refer to the program's online help file.

FILE LIST:
Setup.exe     - AutoWhat? installation program
readme.txt    - the file you are reading
license.txt   - PC Magazine Utilities license agreement
auto_src.zip  - AutoWhat? source code (for programmers)

SUPPORT:
Help for PC Magazine's free utilities can be obtained in our online discussion area on the World Wide Web (http://discuss.pcmag.com/pcmag). You may find an answer to your question simply by reading the posted messages. The authors of current utilities generally visit this forum daily. If the author is not available and the forum sysops can't answer your question, the Utilities column editor, who also checks the forum each day, will contact the author for you.

LICENSE INFORMATION:
PC Magazine programs are copyrighted and cannot be distributed, whether modified or unmodified. Use is subject to the terms and conditions of the license agreement distributed with the programs.

----

Neil J. Rubenking, the author of AutoWhat?, is the Contributing Technical Editor of PC Magazine. Sheryl Canter is the editor of the Utilities column, and a Contributing Editor of PC Magazine.

