Mailto_URL context menu item for IE4+.

This add-on context menu item allows you to open a mail client window and
add the web page Title and URL to it.
Handy if you want to refer someone to the page in an
E-Mail or Newsgroup post. Requires Internet Explorer 4 or higher.

The .zip file should contain 3 files:

	Readme.txt
	Mailto_URL.reg
	Mailto_URL.htm

To install, move Mailto_URL.htm to C:\Windows\Web folder, then double-click
the Mailto_URL.reg file to add the context menu key to the Registry.

To use, just right-click anywhere in a web page and select "E-mail page".
The url will be copied to the subject and the title plus url to the body of the new
message

To uninstall, you need to manually edit the Registry, and delete the key:

	HKCU\Software\Microsoft\Internet Explorer\MenuExt\E-mail Page

If you do not know how to delete a Registry key, e-mail me at
sweber@cdolive.com.  At some point I will write an install-uninstall script for
this utility.

<.SIG />

rev 1 Dec 2001