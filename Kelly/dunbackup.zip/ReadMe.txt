-----------------------------------------------------------------------------
                             DUN-Backup 1.01
-----------------------------------------------------------------------------


----------------------------
ARBEITEN MIT DIESEM DOKUMENT
----------------------------

Maximieren Sie das Editor-Fenster, um diese Datei auf dem
Bildschirm anzuzeigen.

Um die Datei ReadMe.txt zu drucken, �ffnen Sie sie im Editor
oder einem anderen Textverarbeitungsprogramm, und w�hlen Sie
im Men� "Datei" den Befehl "Drucken".



------
INHALT
------

INSTALLATION
KURZANLEITUNG
BEKANNTE PROBLEME
ADRESSE DES AUTORS

----------------
 

INSTALLATION
============

Packen Sie alle Dateien des ZIP-Archivs in einen beliebigen Ordner
aus. Installieren Sie DUN-Backup danach mit dem Programm Setup.


KURZANLEITUNG
=============

Starten Sie DUN-Backup z.B. �ber den Link auf dem Desktop. Unter 
Windows 2000/XP kann das Einlesen der Verbindungen, besonders bei 
einer gr��eren Anzahl Verbindungen, eine gewissen Zeit in Anspruch
nehmen.
Klicken Sie auf "Weiter".

Verbindungen sichern
--------------------

W�hlen Sie "DF�-Netzwerkverbindungen sichern" und klicken Sie auf "Weiter".
W�hlen Sie die Verbindungen, die gesichert werden sollen (Standard alle 
Verbindungen) und klicken Sie auf "Weiter".
W�hlen Sie den Ordner, in den die Verbindungen in eine Datei gesichert 
werden sollen. Geben Sie einen Dateinamenenszusatz ein, der hinzugef�gt 
werden soll, um die bestehende Sicherungsdatei nicht �berschreiben lassen.
Klicken Sie auf "Weiter".

Klicken Sie auf "Fertig stellen", um die Sicherung durchzuf�hren.

Hinweise:
Unter Windows 2000/XP werden die Passworte nicht gespeichert, eine Software
kann diese nicht auslesen. Sie m�ssen sicher daher die Passworte selbst 
merken oder verwenden Sie z.B. das Programme "Alle meine Passworte", gibt
es auf der Seite www.wt-rate.com/freeware.htm.

Der Name der Backup-Datei hei�t immer DUN-Backup<dateinamenszusatz>.dat.
dateinamenszusatz entspricht dem Zusatz, den Sie bei der Sicherung 
angegeben haben. Benennen Sie niemals die Datei, sonst findet DUN-Backup
die eigene Datei nicht wieder.


Verbindungen wiederherstellen
-----------------------------

W�hlen Sie "Zuvor gesicherte DF�-Netzwerkverbindungen" wiederherstellen"
und klicken Sie auf "Weiter".
Legen Sie den Ordner fest, in dem sich die Backup-Datei befindet und w�hlen
Sie danach die Backup-Datei mit dne Verbindungen, die wiederhergestellt 
werden sollen. Klicken Sie anschlie�end auf "Weiter".
W�hlen Sie die Verbindungen, die wiederhergestellt werden sollen, Standard
sind alle Verbindungen, die in der Backup-Datei gefunden wurden.
Klicken Sie auf "Weiter" und anschlie�end auf "Fertig stellen", um die 
Verbindungen wiederherstellen zu lassen.



BEKANNTE PROBLEME
=================

Beim Starten von DUN-Backup wird die Meldung

  "Dieses Element ben�tigt COMCTL32.DLL in der Version 4.70
   oder h�her"
   
ausgegeben. In diesem Fall ben�tigen Sie ein Update der
Datei COMCTL32.dll. Sie finden dieses Update bei Microsoft
oder k�nnen es direkt unter 

   http://www.wt-rate.com/40comupd/40comupd.zip (385 KB)
   
downloaden.



ADRESSE DES AUTORS
==================

Adresse: Mirko B�er
         Prinzenweg 14

         04277 Leipzig
         info@wt-rate.com
         
         Hotline: 0179/1317529 (nicht f�r Freeware-Programme!)

         http://www.wt-rate.com/

         ICQ: 193477 (siehe http://www.mirabilis.com/)

         Mitglied der Shareware Autoren VEreinigung (SAVE)



------------
07.12.2002
