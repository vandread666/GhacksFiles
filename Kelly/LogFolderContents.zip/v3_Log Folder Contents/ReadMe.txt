Log Files or Folder Contents, V3.0
By Steve Yandl, November 30, 2001

Installing this script will add an item to your SendTo menu called "Log Folder Contents"  If you send any files or folders (real folders, not virtual ones) to "Log Folder Contents" a new file will be created in your "My Documents" folder
(or an existing one will be updated) called FolderLog.txt.  The first new line in the text file will be a date/time notice. If files are sent, file name(s) and the name of the parent folder is shown.  If folders are sent, lines are written naming all contained files, subfolders, and contents of all subfolders.  File names are shown with extension and no other file information is presented.  Compressed files are treated as files and the contents are not logged.

The script and the installation script require the latest version of Windows Scripting Host.  It should work on Win9x/ME/2000/XP.  To install, make sure that "LogContents.wsf" is kept in the same folder as "Install LogContents.wsf" and simply double click "Install LogContents.wsf"  If you have the correct version of Windows Scripting Host, you will receive a message box confirming the addition to your SendTo.

The install script creates the folder "Yandl_Scripts" in your Windows folder if it doesn't already exist.  It then makes a copy of LogContents.wsf in that folder.  Finally, it locates your SendTo folder and places a shortcut to LogContents.wsf in the SendTo folder.  No changes are made to the registry or system files.  Uninstalling is simply a matter of deleting the new folder and copied file plus deleting the shortcut.

This version (v2.0) cuts out some of the extra verbage on the date time stamp statement.  It also trimmed the presentation for documenting a group of files.  The install script will delete the previous version prior to installing itself.

