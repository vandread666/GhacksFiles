
CROA 1.3 � 2000-2002 David Crowell
-----------------------------------

DESCRIPTION:
-----------------------------------
CROA - Clear Read-Only Attributes
CROA adds an entry to the context menu for folders that allows you to clear the read-only flag of that folder, all subfolders, and files.  This is particularly useful after copying files from a CD-ROM to the hard-drive.

AUTHOR:
-----------------------------------
David Crowell
http://www.davidcrowell.com
mailto:dave@davidcrowell.com

VERSION HISTORY:
-----------------------------------
Version 1.3 - released February 4, 2003
    . Now supports Windows XP Themes
    . Cosmetic changes

Version 1.2 - released January 9, 2003
    . CROA now starts near the cursor position

Version 1.1 - released December 10, 2002
    . Re-written using Delphi 5 to avoid the VB runtime dependency
    . Fixed cosmetic bug in path display
    . Improved installer

Version 1.0 - released August 12, 2000
    . Original release