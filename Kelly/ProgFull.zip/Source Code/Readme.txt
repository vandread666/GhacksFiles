ReadMe.txt
=====================================================================
Source Code of "StartBtn Renamer"
Version 2.02
Development Tool: Delphi 5

StartBtn Renamer is Open Source. This means that the source code
of the program is presented with it, so that you could change it according
to your own taste and wish, therefore you can add more possibilities on it.
(Any commercial use of this source code, without permission of the author is forbidden).
For more info about the Open Source theory, visit OpenSource.org

What is "Start Button Renamer"?
=====================================================================
StartBtn Renamer is a simple utility for renaming the [Start] button in
Windows XP. With this freeware tool, you can change default Label of
the [Start] button with your own text. This is great when you want to
tease your friends or when you intend to have a greater variety in
Windows... what do you think about these labels: Virus, Hello, Begin, Enter, etc.


How to use "StartBtn Renamer"?
=====================================================================
  "StartBtn Renamer" is very easy-to-use; to rename the [Start]
button, simply run the file 'StartBtn.exe' and then type your desirable
label in the 'New Label' field.


How to run "StartBtn Renamer" from Command-Line?
=====================================================================
You can also rename the [Start] button by running the 'StartBtn.exe'
from the MS-DOS Command Prompt.
- Usage:
    StartBtn.exe NewLabel
    NewLabel parameter is the new label for the [Start] button.

- Example:
    StartBtn.exe Haha
    Changes Label of the [Start] to 'Haha'.

This can be most useful when you want to rename
the [Start] button at the Windows Startup.

=====================================================================

  "StartBtn Renamer" is copyrighted Freeware. Please feel free to use 
it, copy it, upload it to software archives or put it on CD-ROMs, but 
do not change the files included in the package and only distribute 
the package as a whole, not only the single executable.

LICENSE
========================================================================
StarPW Revealer's Source Code is Freeware. You may copy source files AS LONG AS YOU 
COPY ALL OF THEM. If you want to change the source code in order to improve the 
application's features, performance, etc, please send me the new source code so that I can 
have a look at it. The changed source code should contain descriptions what you have 
changed, and of course your name. The only thing you MAY NOT CHANGE is the ORIGINAL 
COPYRIGHT INFORMATION.


for news and updates visit:
http://www.startbtn.main-page.com
http://www.geocities.com/startbtn

Copyright (c) 2002 by AmirBehzad ESLAMI.
All rights reserved.