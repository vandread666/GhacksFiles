/* JS/Compressor v2.02 
   Compress .exe files by StripReloc and UPX utilities
   Programmer: AmirBehzad ESLAMI (ab_eslami@worldsites.com) */

AppTitle = "JS/Compressor - " + "StartBtn Renamer";
Prg_File = "StartBtn.exe";

UPX_File    = "exePackers\\upx.exe";
StripR_File = "exePackers\\StripReloc.exe";

Message = "This JScript program will run UPX utility to compress the file " + Prg_File + "\n" +
          "Do you wish to continue?";

mbYes = 6;
mbYesNo = 4;
mbInfo = 64;
mbWarning = 48;
runNormal = 1;

var WSHShell = WScript.CreateObject("WScript.Shell");
var FSO = new ActiveXObject("Scripting.FileSystemObject");
with (WSHShell) {
 if (Popup(Message, 0, AppTitle, mbYesNo + mbInfo) == mbYes)
   if ((FSO.FileExists(UPX_File)) & (FSO.FileExists(Prg_File)) &  (FSO.FileExists(StripR_File))) {
       var orgPrgFileSize = FSO.GetFile(Prg_File).size;        // Get current size of Prg_File in bytes
       run(StripR_File + " /B " + Prg_File, runNormal, true);  // Strip relocation section from Prg_File...
       run(UPX_File + " -9 " + Prg_File, runNormal, true);     // Compress Prg_File by UPX...
       var newPrgFileSize = FSO.GetFile(Prg_File).size;        // Get new size of Prg_File (after the compression)
       var differenceFileSize = orgPrgFileSize - newPrgFileSize;
       if (!differenceFileSize) {
         WScript.Echo(Prg_File + " has already been compressed!");
         WScript.Quit();
       }
       Popup("The file " + Prg_File + " compressed successfully.\n" + 
         orgPrgFileSize + " bytes --> " + newPrgFileSize + " bytes.\n" +
         differenceFileSize + " bytes difference.", 0, "Summary", mbInfo);
       WScript.Quit();
   }
   else
      Popup(StripR_File + " or " + UPX_File + " or " + Prg_File + " not found.", 0, "Warning", mbWarning);
}
WScript.Quit();