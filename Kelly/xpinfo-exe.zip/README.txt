
                The XPInfo Utility - Version 2002-05-29

                          Fully Licensed GmbH

               Rudower Chaussee 29, 12489 Berlin, Germany

                       http://www.licenturion.com

* XPInfo compares the current hardware configuration - as seen by the
  WPA mechanism - to the hardware configuration at the time of product
  activation and displays the components in which the configurations
  differ.

* XPInfo thus does not work with installations of XP that do not
  require activation, i.e. volume-licensed installations or
  installations of OEM versions.

* Since XPInfo is based on undocumented functionality, it only works
  with

  - build 2600
  - build 2600 + hotfix Q306676

  Any upgrade potentially breaks this version of XPInfo. Although it
  has only been tested with the English and German Professional and
  Home editions of XP, we expect it to work with other versions.

* Invoke "XPInfo.exe" to use the utility. A dialog box containing the
  configuration information will appear.

* A check mark indicates that the corresponding hardware component has
  not been removed, replaced or newly added since product activation.

* If a hardware component is not present in the current hardware
  configuration, it will look dimmed, i.e. it will be displayed in
  a light grey font instead of the usual black font.

* Handling error messages

  o If you see an error message complaining about "entry points", then
    your version is too different from the builds that XPInfo was tested
    with. Unfortunately there is no way for you to use XPInfo in this
    case.

  o If your installation is activated but you see an error message
    asking whether your installation is "really activated", you have to
    supply the number identifying your version of XP to XPInfo. This
    involves five simple steps.

    - Start Internet Explorer.

    - Select the "About" menu item from the "Help" menu.

    - Find the Product ID in the window that has been opened. The
      Product ID consists of 20 digits that are grouped as follows.

                        AAAAA-BBB-CCCCCCC-DDDDD

    - Memorize the leftmost group of digits ("AAAAA") of your
      Product ID.

    - Use "Run..." in the start menu to invoke "XPInfo.exe" with a
      command line parameter of "AAAAA", as in "XPInfo AAAAA", typing
      the memorized five digits instead of "AAAAA".

