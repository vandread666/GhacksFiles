HDD Guardian		<http://code.google.com/p/hddguardian/>
			<http://hddguardian.codeplex.com/>
---------------------------------------------------------------------------
Copyright (C) 2010-2015 Parise Samuele

This program is released under Mozilla Public License 2.0.

<http://mozilla.org/MPL/2.0/>

This software are developed using Microsoft Visual Basic 2012 Express
Edition under Windows 7, and require the .NET Framework 4.0.

MPL 2.0 license is also applied on Translation tool, Toolbox and
Logical Disk Monitor
---------------------------------------------------------------------------


Smart Monitoring Tools	<http://smartmontools.sourceforge.net/>
---------------------------------------------------------------------------
	Copyright (C) 2002-13 by Bruce Allen, Christian Franke
	This utilities are licensed under the GNU GPL 2.0
	<http://www.gnu.org/licenses/old-licenses/gpl-2.0.html>
---------------------------------------------------------------------------


For other attributions see File -> About -> Credits tab on HDD Guardian.